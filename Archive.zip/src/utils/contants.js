const You_API_KEY = "AIzaSyDNpCIvcJ8zzCMjPbkJZqEENFIp8bqUr1c";

export const YOUTUBE_VIDEOS_API =
  "https://youtube.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&chart=mostPopular&maxResults=50&regionCode=IN&key=" +
  You_API_KEY;

export const YouTube_Search_API =
  "http://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=";
